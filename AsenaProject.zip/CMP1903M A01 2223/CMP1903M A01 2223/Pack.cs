﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMP1903M_A01_2223
{
    class Pack
    {
        public static List<Card> Deck;

        public Pack()
        {
            for (int i = 1; i < 5; i++)//Suit values 1-4
            {
                for (int j = 1; j < 15; j++)//Card values 1-13 
                {
                    Deck.Add(Card.CreatingCard(i, j));
                }
            }
        }

        public static bool ShuffleCardPack(int TypeOfShuffle)
        {
            bool Shuffled = false;


            return Shuffled;
        }
        public static Card Deal()
        {
            //Deals one card

        }
        public static List<Card> DealCard(int Amount)
        {
            //Deals the number of cards specified by 'amount'
        }
    }
}
