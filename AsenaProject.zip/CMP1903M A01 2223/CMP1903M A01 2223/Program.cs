﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMP1903M_A01_2223
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Card> GamePack = Pack.Deck; //Create deck

            //Shuffle
            Console.WriteLine("How would you like the deck to be shuffled: 1: Fisher-Yates Shuffle  2: Riffle Shuffle  3: No Shuffle ?"); //check players desired shuffle
            int DesiredShuffle = Convert.ToInt32(Console.ReadLine()); //store desiredshuffle
            if (DesiredShuffle <1 && DesiredShuffle >3)
            {
                bool Shuffled = Pack.ShuffleCardPack(DesiredShuffle);
            }
         }
     }
}
