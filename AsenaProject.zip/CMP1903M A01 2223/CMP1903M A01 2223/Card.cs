﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMP1903M_A01_2223
{
    public enum Suit //to set the suit of the card
    {
        Club = 1,
        Diamond = 2,
        Heart = 3,
        Spades = 4,
    }

    public enum Value //to set the value of the card
    {
        Ace = 1,
        Two = 2,
        Three = 3,
        Four = 4,
        Five = 5,
        Six = 6,
        Seven = 7,
        Eight = 8,
        Nine = 9,
        Ten = 10,
        Jack = 11,
        Queen = 12,
        King = 13,
    }
    class Card
    {
        public int Value { get; set; }
        public int Suit { get; set; }

        public static Card CreatingCard(int iSuit, int iValue)
        {
            Card NewCard = new Card();
            NewCard.Value = iValue;
            NewCard.Suit = iSuit;
            return NewCard;
        }
    }
}
